<?php
//We are now using tickets.php but we need to keep view.php for backward compatibility
require('tickets.php');
?>
