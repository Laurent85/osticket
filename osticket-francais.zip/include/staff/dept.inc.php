<?php
if(!defined('OSTADMININC') || !$thisuser->isadmin()) die('Access Denied');
$info=null;
if($dept && $_REQUEST['a']!='new'){
    //Editing Department.
    $title='Modifier D&eacute;partment';
    $action='update';
    $info=$dept->getInfo();
}else {
    $title='Nouveau D&eacute;partment';
    $action='create';
    $info['ispublic']=isset($info['ispublic'])?$info['ispublic']:1;
    $info['ticket_auto_response']=isset($info['ticket_auto_response'])?$info['ticket_auto_response']:1;
    $info['message_auto_response']=isset($info['message_auto_response'])?$info['message_auto_response']:1;
}
$info=Format::htmlchars(($errors && $_POST)?$_POST:$info);

?>
<div class="msg"><?=$title?></div>
<table width="100%" border="0" cellspacing=0 cellpadding=0>
 <form action="admin.php?t=dept&id=<?=$info['dept_id']?>" method="POST" name="dept">
 <input type="hidden" name="do" value="<?=$action?>">
 <input type="hidden" name="a" value="<?=Format::htmlchars($_REQUEST['a'])?>">
 <input type="hidden" name="t" value="dept">
 <input type="hidden" name="dept_id" value="<?=$info['dept_id']?>">
 <tr><td>
    <table width="100%" border="0" cellspacing=0 cellpadding=2 class="tform">
        <tr class="header"><td colspan=2>D&eacute;partment</td></tr>
        <tr class="subheader"><td colspan=2 >Le d&eacute;partement choisi d&eacute;pend de l'email et des options des cat&eacute;gories pour les tickets entrants.</td></tr>
        <tr><th>Nom du Dept :</th>
            <td><input type="text" name="dept_name" size=25 value="<?=$info['dept_name']?>">
                &nbsp;<font class="error">*&nbsp;<?=$errors['dept_name']?></font>
                    
            </td>
        </tr>
        <tr>
            <th>Email du Dept :</th>
            <td>
                <select name="email_id">
                    <option value="">Choisissez</option>
                    <?
                    $emails=db_query('SELECT email_id,email,name,smtp_active FROM '.EMAIL_TABLE);
                    while (list($id,$email,$name,$smtp) = db_fetch_row($emails)){
                        $email=$name?"$name &lt;$email&gt;":$email;
                        if($smtp)
                            $email.=' (SMTP)';
                        ?>
                     <option value="<?=$id?>"<?=($info['email_id']==$id)?'selected':''?>><?=$email?></option>
                    <?
                    }?>
                 </select>
                 &nbsp;<font class="error">*&nbsp;<?=$errors['email_id']?></font>&nbsp;(email utilis&eacute; pour l'envoi)
            </td>
        </tr>    
        <? if($info['dept_id']) { //update 
            $users= db_query('SELECT staff_id,CONCAT_WS(" ",firstname,lastname) as name FROM '.STAFF_TABLE.' WHERE dept_id='.db_input($info['dept_id']));
            ?>
        <tr>
            <th>Manager du Dept:</th>
            <td>
                <?if($users && db_num_rows($users)) {?>
                <select name="manager_id">
                    <option value=0 >------Aucun------</option>
                    <option value=0 disabled >Selectionner Manager (optionnel)</option>
                     <?
                     while (list($id,$name) = db_fetch_row($users)){ ?>
                        <option value="<?=$id?>"<?=($info['manager_id']==$id)?'selected':''?>><?=$name?></option>
                     <?}?>
                     
                </select>
                 <?}else {?>
                       Aucun utilisateur (Ajouter Utilisateur)
                       <input type="hidden" name="manager_id"  value="0" />
                 <?}?>
                    &nbsp;<font class="error">&nbsp;<?=$errors['manager_id']?></font>
            </td>
        </tr>
        <?}?>
        <tr><th>Type de Dept :</th>
            <td>
                <input type="radio" name="ispublic"  value="1"   <?=$info['ispublic']?'checked':''?> />Public
                <input type="radio" name="ispublic"  value="0"   <?=!$info['ispublic']?'checked':''?> />Priv&eacute; (Cach&eacute;)
                &nbsp;<font class="error"><?=$errors['ispublic']?></font>
            </td>
        </tr>
        <tr>
            <th valign="top"><br/>Signature du Dept :</th>
            <td>
                <i>Requis quand le Dept. est public</i>&nbsp;&nbsp;&nbsp;<font class="error"><?=$errors['dept_signature']?></font><br/>
                <textarea name="dept_signature" cols="21" rows="5" style="width: 60%;"><?=$info['dept_signature']?></textarea>
                <br>
                <input type="checkbox" name="can_append_signature" <?=$info['can_append_signature'] ?'checked':''?> > 
                peut &ecirc;tre ajout&eacute; aux r&eacute;ponses .&nbsp;(au choix pour les d&eacute;partement publics)  
            </td>
        </tr>
        <tr><th>Templates des emails:</th>
            <td>
                <select name="tpl_id">
                    <option value=0 disabled>Choisissez un template</option>
                    <option value="0" selected="selected">Par d&eacute;faut</option>
                    <?
                    $templates=db_query('SELECT tpl_id,name FROM '.EMAIL_TEMPLATE_TABLE.' WHERE tpl_id!='.db_input($cfg->getDefaultTemplateId()));
                    while (list($id,$name) = db_fetch_row($templates)){
                        $selected = ($info['tpl_id']==$id)?'SELECTED':''; ?>
                        <option value="<?=$id?>"<?=$selected?>><?=Format::htmlchars($name)?></option>
                    <?
                    }?>
                </select><font class="error">&nbsp;<?=$errors['tpl_id']?></font><br/>
                <i>Utilis&eacute; pour les emails envoy&eacute;s, alertes et notifications pour l'utilisateur et le staff.</i>
            </td>
        </tr>
        <tr class="header"><td colspan=2>R&eacute;ponses auto.</td></tr>
        <tr class="subheader"><td colspan=2>
            L'option g&eacute;n&eacute;rale des r&eacute;ponses auto. doit &ecirc;tre activ&eacute; dans les pr&eacute;f&eacute;rences.
            </td>
        </tr>
        <tr><th>Nouveau ticket:</th>
            <td>
                <input type="radio" name="ticket_auto_response"  value="1"   <?=$info['ticket_auto_response']?'checked':''?> />Activer
                <input type="radio" name="ticket_auto_response"  value="0"   <?=!$info['ticket_auto_response']?'checked':''?> />D&eacute;sactiver
            </td>
        </tr>
        <tr><th>Nouveau Message:</th>
            <td>
                <input type="radio" name="message_auto_response"  value="1"   <?=$info['message_auto_response']?'checked':''?> />Activer
                <input type="radio" name="message_auto_response"  value="0"   <?=!$info['message_auto_response']?'checked':''?> />D&eacute;sactiver
            </td>
        </tr>
        <tr>
            <th>Email pour les r&eacute;ponses auto :</th>
            <td>
                <select name="autoresp_email_id">
                    <option value="0" disabled>Choisissez</option>
                    <option value="0" selected="selected">Email du d&eacute;partement (ci-dessus)</option>
                    <?
                    $emails=db_query('SELECT email_id,email,name,smtp_active FROM '.EMAIL_TABLE.' WHERE email_id!='.db_input($info['email_id']));
                    if($emails && db_num_rows($emails)) {
                        while (list($id,$email,$name,$smtp) = db_fetch_row($emails)){
                            $email=$name?"$name &lt;$email&gt;":$email;
                            if($smtp)
                                $email.=' (SMTP)';
                            ?>
                            <option value="<?=$id?>"<?=($info['autoresp_email_id']==$id)?'selected':''?>><?=$email?></option>
                        <?
                        }
                    }?>
                 </select>
                 &nbsp;<font class="error">&nbsp;<?=$errors['autoresp_email_id']?></font>&nbsp;<br/>
                 <i>Adresse mail utilis&eacute;e pour les r&eacute;ponses auto, si activ&eacute;es.</i>
            </td>
        </tr>
    </table>
    </td></tr>
    <tr><td style="padding:10px 0 10px 200px;">
        <input class="button" type="submit" name="submit" value="Valider">
        <input class="button" type="reset" name="reset" value="R&eacute;initialiser">
        <input class="button" type="button" name="cancel" value="Annuler" onClick='window.location.href="admin.php?t=dept"'>
    </td></tr>
    </form>
</table>
