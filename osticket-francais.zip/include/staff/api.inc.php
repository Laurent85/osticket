<?php
if(!defined('OSTADMININC') || !$thisuser->isadmin()) die('Access Denied');


$info['phrase']=($errors && $_POST['phrase'])?$_POST['phrase']:$cfg->getAPIPassphrase();
$select='SELECT * ';
$from='FROM '.API_KEY_TABLE;
$where='';
$sortOptions=array('date'=>'created','ip'=>'ipaddr');
$orderWays=array('DESC'=>'DESC','ASC'=>'ASC');
//Sorting options...
if($_REQUEST['sort']) {
    $order_column =$sortOptions[$_REQUEST['sort']];
}

if($_REQUEST['order']) {
    $order=$orderWays[$_REQUEST['order']];
}
$order_column=$order_column?$order_column:'ipaddr';
$order=$order?$order:'ASC';
$order_by=" ORDER BY $order_column $order ";

$total=db_count('SELECT count(*) '.$from.' '.$where);
$pagelimit=1000;//No limit.
$page=($_GET['p'] && is_numeric($_GET['p']))?$_GET['p']:1;
$pageNav=new Pagenate($total,$page,$pagelimit);
$pageNav->setURL('admin.php',$qstr.'&sort='.urlencode($_REQUEST['sort']).'&order='.urlencode($_REQUEST['order']));
$query="$select $from $where $order_by";
//echo $query;
$result = db_query($query);
$showing=db_num_rows($result)?$pageNav->showing():'';
$negorder=$order=='DESC'?'ASC':'DESC'; //Negate the sorting..
$deletable=0;
?>
<div class="msg">Cl&eacute;s API</div>
<hr>
<div><b><?=$showing?></b></div>
 <table width="100%" border="0" cellspacing=1 cellpadding=2>
   <form action="admin.php?t=api" method="POST" name="api" onSubmit="return checkbox_checker(document.forms['api'],1,0);">
   <input type=hidden name='t' value='api'>
   <input type=hidden name='do' value='mass_process'>
   <tr><td>
    <table border="0" cellspacing=0 cellpadding=2 class="dtable" align="center" width="100%">
        <tr>
	        <th width="7px">&nbsp;</th>
	        <th>Cl&eacute; API</th>
            <th width="10" nowrap>Activ&eacute;</th>
            <th width="100" nowrap>&nbsp;&nbsp;Address IP</th>
	        <th width="150" nowrap>&nbsp;&nbsp;
                <a href="admin.php?t=api&sort=date&order=<?=$negorder?><?=$qstr?>" title="Trier par date de cr&eacute;ation <?=$negorder?>">Cr&eacute;&eacute;</a></th>
        </tr>
        <?
        $class = 'row1';
        $total=0;
        $active=$inactive=0;
        $sids=($errors && is_array($_POST['ids']))?$_POST['ids']:null;
        if($result && db_num_rows($result)):
            $dtpl=$cfg->getDefaultTemplateId();
            while ($row = db_fetch_array($result)) {
                $sel=false;
                $disabled='';
                if($row['isactive'])
                    $active++;
                else
                    $inactive++;
                    
                if($sids && in_array($row['id'],$sids)){
                    $class="$class highlight";
                    $sel=true;
                }
                ?>
            <tr class="<?=$class?>" id="<?=$row['id']?>">
                <td width=7px>
                  <input type="checkbox" name="ids[]" value="<?=$row['id']?>" <?=$sel?'checked':''?>
                        onClick="highLight(this.value,this.checked);">
                <td>&nbsp;<?=$row['apikey']?></td>
                <td><?=$row['isactive']?'<b>Yes</b>':'No'?></td>
                <td>&nbsp;<?=$row['ipaddr']?></td>
                <td>&nbsp;<?=Format::db_datetime($row['created'])?></td>
            </tr>
            <?
            $class = ($class =='row2') ?'row1':'row2';
            } //end of while.
        else: //nothin' found!! ?> 
            <tr class="<?=$class?>"><td colspan=5><b>La requ&ecirc; a retourn&eacute; 0 r&eacute;sultats</b>&nbsp;&nbsp;<a href="admin.php?t=templates">Liste des index</a></td></tr>
        <?
        endif; ?>
     
     </table>
    </td></tr>
    <?
    if(db_num_rows($result)>0): //Show options..
     ?>
    <tr>
        <td align="center">
            <?php
            if($inactive) {?>
                <input class="button" type="submit" name="enable" value="Activer"
                     onClick='return confirm("Etes vous sur de vouloir activer ces cl�s ?");'>
            <?php
            }
            if($active){?>
            &nbsp;&nbsp;
                <input class="button" type="submit" name="disable" value="Desactiver"
                     onClick='return confirm("Etes vous sur de vouloir desactiver ces cl�s ?");'>
            <?}?>
            &nbsp;&nbsp;
            <input class="button" type="submit" name="delete" value="Supprimer" 
                     onClick='return confirm("Etes vous sur de vouloir supprimer ces cl�s ?");'>
        </td>
    </tr>
    <?
    endif;
    ?>
    </form>
 </table>
 <br/>
 <div class="msg">Ajouter une nouvelle IP</div>
 <hr>
 <div>
   Ajouter une nouvelle adresse IP.<br/>
   <form action="admin.php?t=api" method="POST" >
    <input type=hidden name='t' value='api'>
    <input type=hidden name='do' value='add'>
    Nouvelle IP:
    <input name="ip" size=30 value="<?=($errors['ip'])?Format::htmlchars($_REQUEST['ip']):''?>" />
    <font class="error">*&nbsp;<?=$errors['ip']?></font>&nbsp;&nbsp;
     &nbsp;&nbsp; <input class="button" type="submit" name="add" value="Ajouter">
    </form>
 </div>
 <br/>
 <div class="msg">Mot de passe API</div>
 <hr>
 <div>
   Le mot de passe doit contenir au moins 3 mots. Requis pour g&eacute;n&eacute;rer les cl&eacute; API.<br/>
   <form action="admin.php?t=api" method="POST" >
    <input type=hidden name='t' value='api'>
    <input type=hidden name='do' value='update_phrase'>
    Phrase:
    <input name="phrase" size=50 value="<?=Format::htmlchars($info['phrase'])?>" />
    <font class="error">*&nbsp;<?=$errors['phrase']?></font>&nbsp;&nbsp;
     &nbsp;&nbsp; <input class="button" type="submit" name="update" value="Valider">
    </form>
    <br/><br/>
    <div><i>Veuillez noter que changer le mot de passe n'invalide pas les cl&eacute;s existantes. Pour ce faire, vous devez d'abord la supprimer. </i></div>
 </div>
