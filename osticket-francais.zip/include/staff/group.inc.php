<?php
if(!defined('OSTADMININC') || !$thisuser->isadmin()) die('Access Denied');

$info=Format::htmlchars(($errors && $_POST)?$_POST:$group);
if($group && $_REQUEST['a']!='new'){
    $title='Modifier groupe : '.$group['group_name'];
    $action='update';
}else {
    $title='Ajouter nouveau groupe';
    $action='create';
    $info['group_enabled']=isset($info['group_enabled'])?$info['group_enabled']:1; //Default to active 
}

?>
<table width="100%" border="0" cellspacing=0 cellpadding=0>
 <form action="admin.php" method="POST" name="group">
 <input type="hidden" name="do" value="<?=$action?>">
 <input type="hidden" name="a" value="<?=Format::htmlchars($_REQUEST['a'])?>">
 <input type="hidden" name="t" value="groups">
 <input type="hidden" name="group_id" value="<?=$info['group_id']?>">
 <input type="hidden" name="old_name" value="<?=$info['group_name']?>">
 <tr><td>
    <table width="100%" border="0" cellspacing=0 cellpadding=2 class="tform">
        <tr class="header"><td colspan=2><?=Format::htmlchars($title)?></td></tr>
        <tr class="subheader"><td colspan=2>
            Les permissions des groupes ci-dessous s'appliquent pour tous les membres du groupe, mais non pour les administrateurs et managers dans certains cas.
            </td></tr>
        <tr><th>Nom du groupe :</th>
            <td><input type="text" name="group_name" size=25 value="<?=$info['group_name']?>">
                &nbsp;<font class="error">*&nbsp;<?=$errors['group_name']?></font>
                    
            </td>
        </tr>
        <tr>
            <th>Statut du groupe:</th>
            <td>
                <input type="radio" name="group_enabled"  value="1"   <?=$info['group_enabled']?'checked':''?> /> Actif
                <input type="radio" name="group_enabled"  value="0"   <?=!$info['group_enabled']?'checked':''?> />Inactif
                &nbsp;<font class="error">&nbsp;<?=$errors['group_enabled']?></font>
            </td>
        </tr>
        <tr><th valign="top"><br>Acc&egrave;s au d&eacute;partement</th>
            <td class="mainTableAlt"><i>Selectionner les d&eacute;partements auxquels seront autoris&eacute;s d'acc&eacute;der aux membres de ce groupe.</i>
                &nbsp;<font class="error">&nbsp;<?=$errors['depts']?></font><br/>
                <?
                //Try to save the state on error...
                $access=($_POST['depts'] && $errors)?$_POST['depts']:explode(',',$info['dept_access']);
                $depts= db_query('SELECT dept_id,dept_name FROM '.DEPT_TABLE.' ORDER BY dept_name');
                while (list($id,$name) = db_fetch_row($depts)){
                    $ck=($access && in_array($id,$access))?'checked':''; ?>
                    <input type="checkbox" name="depts[]" value="<?=$id?>" <?=$ck?> > <?=$name?><br/>
                <?
                }?>
                <a href="#" onclick="return select_all(document.forms['group'])">Tout selectionner</a>&nbsp;&nbsp;
                <a href="#" onclick="return reset_all(document.forms['group'])">Aucun</a>&nbsp;&nbsp; 
            </td>
        </tr>
        <tr><th>Peut <b>Supprimer</b> des tickets</th>
            <td>
                <input type="radio" name="can_delete_tickets"  value="1"   <?=$info['can_delete_tickets']?'checked':''?> />Oui 
                <input type="radio" name="can_delete_tickets"  value="0"   <?=!$info['can_delete_tickets']?'checked':''?> />Non
                &nbsp;&nbsp;<i>Les tickets supprim&eacute;s ne peuvent plus &ecirc;tre r&eacute;cup&eacute;r&eacute;s!</i>
            </td>
        </tr>
        <tr><th>Peut <b>Editer</b> des tickets</th>
            <td>
                <input type="radio" name="can_edit_tickets"  value="1"   <?=$info['can_edit_tickets']?'checked':''?> />Oui
                <input type="radio" name="can_edit_tickets"  value="0"   <?=!$info['can_edit_tickets']?'checked':''?> />Non
                &nbsp;&nbsp;<i>Les admins &amp; managers le peuvent par d&eacute;faut.</i>
            </td>
        </tr>
        <tr><th>Peut <b>Fermer en masse</b> des tickets</th>
            <td>
                <input type="radio" name="can_close_tickets"  value="1" <?=$info['can_close_tickets']?'checked':''?> />Oui
                <input type="radio" name="can_close_tickets"  value="0" <?=!$info['can_close_tickets']?'checked':''?> />Non
                &nbsp;&nbsp;<i>Le staff peut toujours fermer des tickets un par un si "Non".</i>
            </td>
        </tr>
        <tr><th>Peut <b>Transf&eacute;rer</b> des tickets</th>
            <td>
                <input type="radio" name="can_transfer_tickets"  value="1" <?=$info['can_transfer_tickets']?'checked':''?> />Oui
                <input type="radio" name="can_transfer_tickets"  value="0" <?=!$info['can_transfer_tickets']?'checked':''?> />Non
                &nbsp;&nbsp;<i>Pouvoir transf&eacute;rer des tickets d'un d&eacute;partement &agrave; un autre.</i>
            </td>
        </tr>
        <tr><th>Peut Bannir des emails</th>
            <td>
                <input type="radio" name="can_ban_emails"  value="1" <?=$info['can_ban_emails']?'checked':''?> />Oui
                <input type="radio" name="can_ban_emails"  value="0" <?=!$info['can_ban_emails']?'checked':''?> />Non
                &nbsp;&nbsp;<i>Pouvoir ajouter/supprimer des adresses mail de la banliste.</i>
            </td>
        </tr>
        <tr><th>Peut G&eacute;rer les r&eacute;ponses auto.</th>
            <td>
                <input type="radio" name="can_manage_kb"  value="1" <?=$info['can_manage_kb']?'checked':''?> />Oui
                <input type="radio" name="can_manage_kb"  value="0" <?=!$info['can_manage_kb']?'checked':''?> />Non
                &nbsp;&nbsp;<i>Pouvoir ajouter/modifier/supprimer des r&eacute;ponses auto.</i>
            </td>
        </tr>
    </table>
    <tr><td style="padding-left:165px;padding-top:20px;">
        <input class="button" type="submit" name="submit" value="Valider">
        <input class="button" type="reset" name="reset" value="R&eacute;initialiser">
        <input class="button" type="button" name="cancel" value="Annuler" onClick='window.location.href="admin.php?t=groups"'>
        </td>
    </tr>
 </form>
</table>
