<?php
if(!defined('OSTADMININC') || !$thisuser->isadmin() || !is_object($template)) die('Access Denied');
$tpl=Format::htmlchars(($errors && $_POST)?$_POST:$template->getInfo());
?>
<div class="msg">Templates Email</div>
<table width="100%" border="0" cellspacing=0 cellpadding=0>
  <form action="admin.php?t=templates" method="post">
    <input type="hidden" name="t" value="templates">
    <input type="hidden" name="do" value="update">
    <input type="hidden" name="id" value="<?=$template->getId()?>">
    <tr><td>

        <table width="100%" border="0" cellspacing=0 cellpadding=2 class="tform tpl">
            <tr class="header"><td colspan=2 >Information du template</td></tr>
            <tr class="subheader"><td colspan=2><b>Derni&egrave;re MAJ le <?=Format::db_daydatetime($template->getUpdateDate())?></b></td></tr>
            <tr>
                <th>Nom</th>
                <td>
                    <input type="text" size="45" name="name" value="<?=$tpl['name']?>">
                            &nbsp;<font class="error">*&nbsp;<?=$errors['name']?></font></td>
            </tr>
            <tr>
                <th>Notes internes :</th>
                <td><i>Notes administratives </i>&nbsp;<font class="error">&nbsp;<?=$errors['notes']?></font>
                    <textarea rows="7" cols="75" name="notes"><?=$tpl['notes']?></textarea>
                        &nbsp;<font class="error">&nbsp;<?=$errors['notes']?></font></td>
            </tr>
        </table>
        <div class="msg">Utilisateur</div>
        <table width="100%" border="0" cellspacing=0 cellpadding=2 class="tform tpl">
            <tr class="header"><td colspan=2 >R&eacute;ponse automatique � un nouveau ticket</td></tr>
            <tr class="subheader"><td colspan=2 >
                R&eacute;ponse automatique envoy&eacute; au client si activ&eacute;.
				Utilis&eacute; pour lui fournir l'ID de son ticket afin qu'il puisse suivre la progression de ce ticket.
				</td>
            </tr>
            <tr>
                <th>Sujet</th>
                <td>
                    <input type="text" size="65" name="ticket_autoresp_subj" value="<?=$tpl['ticket_autoresp_subj']?>">
                            &nbsp;<font class="error">&nbsp;<?=$errors['ticket_autoresp_subj']?></font></td>
            </tr>
            <tr>
                <th>Corps du message:</th>
                <td><textarea rows="7" cols="75" name="ticket_autoresp_body"><?=$tpl['ticket_autoresp_body']?></textarea>
                        &nbsp;<font class="error">&nbsp;<?=$errors['ticket_autoresp_body']?></font></td>
            </tr>
            <tr class="header"><td colspan=2 >R&eacute;ponse automatique &agrave; un nouveau message</td></tr>
            <tr class="subheader"><td colspan=2 > 
				Confirmation envoy&eacute;e &agrave; au client quand un message est ajout&eacute; &agrave; un ticket existant (email et web)
                </td>
            </tr>
            <tr>
                <th>Sujet</th>
                <td>
                    <input type="text" size="65" name="message_autoresp_subj" value="<?=$tpl['message_autoresp_subj']?>">
                            &nbsp;<font class="error">&nbsp;<?=$errors['message_autoresp_subj']?></font></td>
            </tr>
            <tr>
                <th>Corps du message:</th>
                <td><textarea rows="7" cols="75" name="message_autoresp_body"><?=$tpl['message_autoresp_body']?></textarea>
                            &nbsp;<font class="error">&nbsp;<?=$errors['message_autoresp_body']?></font></td>
            </tr>
            <tr class="header"><td  colspan=2 >Notification du maximum de tickets atteints</td></tr>
            <tr class="subheader"><td colspan=2 >
                Notification envoy&eacute;e pour alerter le client qu'il a d&eacute;pass&eacute; le nombre maximal de tickets autoris&eacute;s d&eacute;finis dans les pr&eacute;f&eacute;rences.
				<br/>L'administrateur re&ccedil;oit une alerte chaque fois qu'un ticket est refus&eacute;.
            </td></tr>
            <tr>
                <th>Sujet</th>
                <td>
                    <input type="text" size="65" name="ticket_overlimit_subj" value="<?=$tpl['ticket_overlimit_subj']?>">
                            &nbsp;<font class="error">&nbsp;<?=$errors['ticket_overlimit_subj']?></font></td>
            </tr>
            <tr>
                <th>Corps du message :</th>
                <td><textarea rows="7" cols="75" name="ticket_overlimit_body"><?=$tpl['ticket_overlimit_body']?></textarea>
                    &nbsp;<font class="error">&nbsp;<?=$errors['ticket_overlimit_body']?></font></td>
            </tr>
            <tr class="header"><td colspan=2 >&nbsp;R&eacute;ponse &agrave; un ticket</td></tr>
            <tr class="subheader"><td colspan=2 >
                Template utilis&eacute; lors d'une r&eacute;ponse &agrave; un ticket pour alerter le client d'une r&eacute;ponse.
            </td></tr>
            <tr>
                <th>Sujet</th>
                <td>
                    <input type="text" size="65" name="ticket_reply_subj" value="<?=$tpl['ticket_reply_subj']?>">
                            &nbsp;<font class="error">&nbsp;<?=$errors['ticket_reply_subj']?></font></td>
            </tr>
            <tr>
                <th>Corps du message :</td>
                <td><textarea rows="7" cols="75" name="ticket_reply_body"><?=$tpl['ticket_reply_body']?></textarea>
                    &nbsp;<font class="error">&nbsp;<?=$errors['ticket_reply_body']?></font></td>
            </tr>
        </table>
        <span class="msg">Staff</span>
        <table width="100%" border="0" cellspacing=0 cellpadding=2 class="tform tpl">
            <tr class="header"><td colspan=2 >Nouveau ticket</td></tr>
            <tr class="subheader"><td colspan=2 >Alerte envoy&eacute;e au staff (si activ&eacute;) lors d'un nouveau ticket.</td></tr>
            <tr>
                <th>Sujet</th>
                <td>
                    <input type="text" size="65" name="ticket_alert_subj" value="<?=$tpl['ticket_alert_subj']?>">
                            &nbsp;<font class="error">&nbsp;<?=$errors['ticket_alert_subj']?></font></td>
            </tr>
            <tr>
                <th>Corps du message :</th>
                <td><textarea rows="7" cols="75" name="ticket_alert_body"><?=$tpl['ticket_alert_body']?></textarea>
                    &nbsp;<font class="error">&nbsp;<?=$errors['ticket_alert_body']?></font></td>
            </tr>
            <tr class="header"><td colspan=2 >Nouveau message</td></tr>
            <tr class="subheader"><td colspan=2 >Alerte envoy&eacute;e au staff (si activ&eacute;) lors d'une r&eacute;ponse d'un client &agrave; un ticket.</td></tr>
            <tr>
                <th>Sujet</th>
                <td>
                    <input type="text" size="65" name="message_alert_subj" value="<?=$tpl['message_alert_subj']?>">
                            &nbsp;<font class="error">&nbsp;<?=$errors['message_alert_subj']?></font></td>
            </tr>
            <tr>
                <th>Corps du message :</th>
                <td><textarea rows="7" cols="75" name="message_alert_body"><?=$tpl['message_alert_body']?></textarea>
                    &nbsp;<font class="error">&nbsp;<?=$errors['message_alert_body']?></font></td>
            </tr>


            <tr class="header"><td colspan=2 >Nouvelle note interne</td></tr>
            <tr class="subheader"><td colspan=2 >Alerte envoy&eacute;e au staff s&eacute;lectionn&eacute; (si activ&eacute;) lorsqu'une note interne est ajout&eacute;e &agrave; un ticket.</td></tr>
            <tr>
                <th>Sujet</th>
                <td>
                    <input type="text" size="65" name="note_alert_subj" value="<?=$tpl['note_alert_subj']?>">
                            &nbsp;<font class="error">&nbsp;<?=$errors['note_alert_subj']?></font></td>
            </tr>
            <tr>
                <th>Corps du message :</th>
                <td><textarea rows="7" cols="75" name="note_alert_body"><?=$tpl['note_alert_body']?></textarea>
                    &nbsp;<font class="error">&nbsp;<?=$errors['note_alert_body']?></font></td>
            </tr>

            <tr class="header"><td colspan=2 >Assignement de ticket</td></tr>
            <tr class="subheader"><td colspan=2 >Alerte envoy&eacute;e au staff auquel un ticket a &eacute;t&eacute; assign&eacute;.</td></tr>
            <tr>
                <th>Sujet</th>
                <td>
                    <input type="text" size="65" name="assigned_alert_subj" value="<?=$tpl['assigned_alert_subj']?>">
                            &nbsp;<font class="error">&nbsp;<?=$errors['assigned_alert_subj']?></font></td>
            </tr>
            <tr>
                <th>Corps du message :</th>
                <td><textarea rows="7" cols="75" name="assigned_alert_body"><?=$tpl['assigned_alert_body']?></textarea>
                    &nbsp;<font class="error">&nbsp;<?=$errors['assigned_alert_body']?></font></td>
            </tr>
            <tr class="header"><td colspan=2 >Ticket en retard</td></tr>
            <tr class="subheader"><td colspan=2 >Alerte envoy&eacute;e au staff lorsqu'un ticket a d&eacute;pass&eacute; la date d'&eacute;ch&eacute;ance.</td></tr>
            <tr>
                <th>Sujet</th>
                <td>
                    <input type="text" size="65" name="ticket_overdue_subj" value="<?=$tpl['ticket_overdue_subj']?>">
                            &nbsp;<font class="error">&nbsp;<?=$errors['ticket_overdue_subj']?></font></td>
            </tr>
            <tr>
                <th>Corps du message :</th>
                <td><textarea rows="7" cols="75" name="ticket_overdue_body"><?=$tpl['ticket_overdue_body']?></textarea>
                    &nbsp;<font class="error">&nbsp;<?=$errors['ticket_overdue_body']?></font></td>
            </tr>
        </table>
    </td></tr>
    <tr><td style="padding-left:175px">
        <input class="button" type="submit" name="submit" value="Sauvegarder">
        <input class="button" type="reset" name="reset" value="R&eacute;initialiser">
        <input class="button" type="button" name="cancel" value="Annuler" onClick='window.location.href="admin.php?t=email"'></td>
    </tr>
  </form>
</table>
