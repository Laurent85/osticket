<?php
if(!defined('OSTADMININC') || !$thisuser->isadmin()) die('Access Denied');
//Get the config info.
$config=($errors && $_POST)?Format::htmlchars($_POST):$cfg->getConfig();
?>
<table width="100%" border="0" cellspacing=0 cellpadding=0>
    <form action="admin.php?t=attach" method="post">
    <input type="hidden" name="t" value="attach">
    <tr>
      <td>
        <table width="100%" border="0" cellspacing=0 cellpadding=2 class="tform">
          <tr class="header">
            <td colspan=2>&nbsp;Options des pi&egrave;ces jointes</td>
          </tr>
          <tr class="subheader">
            <td colspan="2">
                Avant d'activer les pi&egrave;ces jointes, assurez vous de comprendre les options de s&eacute;curit&eacute;s et les probl&egrave;mes li&eacute; &agrave; l'upload des pi&egrave;ces jointes.</td>
          </tr>
          <tr>
            <th width="165">Autoriser pi&egrave;ces jointes :</th>
            <td>
              <input type="checkbox" name="allow_attachments" <?=$config['allow_attachments'] ?'checked':''?>><b>Autoriser pi&egrave;ces jointes</b>
                &nbsp; (<i>Option g&eacute;n&eacute;rale</i>)
                &nbsp;<font class="error">&nbsp;<?=$errors['allow_attachments']?></font>
            </td>
          </tr>
          <tr>
            <th>Pi&egrave;ces jointes dans les emails :</th>
            <td>
                <input type="checkbox" name="allow_email_attachments" <?=$config['allow_email_attachments'] ? 'checked':''?> > Autoriser
                    &nbsp;<font class="warn">&nbsp;<?=$warn['allow_email_attachments']?></font>
            </td>
          </tr>
         <tr>
            <th>Pi&egrave;ces jointes en ligne :</th>
            <td>
                <input type="checkbox" name="allow_online_attachments" <?=$config['allow_online_attachments'] ?'checked':''?> >
                    Autoriser l'upload pi&egrave;ces jointes en ligne<br/>&nbsp;&nbsp;&nbsp;&nbsp;
                <input type="checkbox" name="allow_online_attachments_onlogin" <?=$config['allow_online_attachments_onlogin'] ?'checked':''?> >
                    Utilisateurs identifi&eacute; seulement. (<i>L'utilisateur doit &ecirc; logg&eacute; pour uploader des fichiers</i>)
                    <font class="warn">&nbsp;<?=$warn['allow_online_attachments']?></font>
            </td>
          </tr>
          <tr>
            <th>Fichiers attach&eacute;s dans les r&eacute;ponses du centre de support :</th>
            <td>
                <input type="checkbox" name="email_attachments" <?=$config['email_attachments']?'checked':''?> >Autoriser
            </td>
          </tr>
          <tr>
            <th nowrap>Taille maximale:</th>
            <td>
              <input type="text" name="max_file_size" value="<?=$config['max_file_size']?>"> <i>bits</i>
                <font class="error">&nbsp;<?=$errors['max_file_size']?></font>
            </td>
          </tr>
          <tr>
            <th>Dossier des pi&egrave;ces jointes :</th>
            <td>
                Le serveur (ex. apache) doit avoir le droit d'&eacute;crire dans le dossier. &nbsp;<font class="error">&nbsp;<?=$errors['upload_dir']?></font><br>
              <input type="text" size=60 name="upload_dir" value="<?=$config['upload_dir']?>"> 
              <font color=red>
              <?=$attwarn?>
              </font>
            </td>
          </tr>
          <tr>
            <th valign="top"><br/>Extensions de fichiers accept&eacute;es :</th>
            <td>
                Entre les extensions autoris&eacute;es s&eacute;par&eacute;es par une virgule. ex. <i>.doc, .pdf, </i> <br>
                Pour accepter tous les fichiers, entrez <b><i>.*</i></b>&nbsp;&nbsp; (NON recommand&eacute;).
                <textarea name="allowed_filetypes" cols="21" rows="4" style="width: 65%;" wrap=HARD ><?=$config['allowed_filetypes']?></textarea>
            </td>
          </tr>
        </table>
    </td></tr>
    <tr><td style="padding:10px 0 10px 200px">
        <input class="button" type="submit" name="submit" value="Sauvegarder">
        <input class="button" type="reset" name="reset" value="Annuler">
    </td></tr>
  </form>
</table>
